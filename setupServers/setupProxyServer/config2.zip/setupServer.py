# -*- encoding: utf-8 -*-
import sys
import ovh
import subprocess
import os
import time

'''
###############################################################
#                                                             #
#                    VARIABLES STATIQUES                      #
#															  #
###############################################################
'''

vps = sys.argv[1]																							#Nom du vps a configurer
commandPath = "./commands"																					#Liste des commandes a effectuer
templateID = 142577																							#Debian 8
sshK = "ssh-key"																							#Cl� standard SSH
defaultLanguage = "en"																						#Language standard anglais
client = ovh.Client()																						#Ovh.conf

'''
###############################################################
#                                                             #
#                REINSTALLATION DU SERVICE                    #
#                                                             #
###############################################################
'''

'''Reinstallation avec les parametres de configuration'''

task = client.post("/vps/" + vps + "/reinstall",doNotSendPassword=False,language=defaultLanguage,sshKey=[sshK],templateId=templateID)

state = task['state']

'''Attente de la fin de la reinstallation'''

while state != 'done':	
	task = client.get("/vps/" + vps + "/tasks/" + task['id'])
	state = task['state']
	time.sleep(30)
	
'''
###############################################################
#                                                             #
#                 CONFIGURATION DU SERVICE                    #
#                                                             #
###############################################################
'''

'''Recuperation des commandes'''

commands = ""

with open(commandPath,'r') as r:
	commands = r.read()
	
'''Separation des nouvelles lignes (une commande par ligne) + formatage avec l'ip'''

commandsList = []

for i in commands.split('\n'):
	commandsList.append(i.format(vps))

'''Envoi des commandes ssh multiples'''

for i in commandsList:
	print("Sending :",i)
	os.system(i)
	

